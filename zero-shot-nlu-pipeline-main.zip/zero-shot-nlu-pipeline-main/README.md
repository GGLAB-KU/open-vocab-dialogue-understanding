This repository contains the prompt templates and the chatbot related files for the work: **A Zero-Shot Open-Vocabulary Pipeline for Dialogue Understanding**
